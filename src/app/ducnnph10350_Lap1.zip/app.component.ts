import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'WEB207 - WE16303 - tuannda3';
  subTitle = 'Bang du lieu'
  student = {
    name: 'ducnnph10350',
    age: 22,
    phone: '0775200414',
    email: 'ducnnph10350@fpt.edu.vn',
    img: 'https://images.contentstack.io/v3/assets/blt731acb42bb3d1659/bltf945a57aa16cea57/5db05fe7347d1c6baa57be37/RiotX_ChampionList_nautilus.jpg?quality=90&width=250'
  };
  students = [
    {
      id: 1,
      name: 'ducnnph10350',
      age: 22,
      phone: '0775200414',
      email: 'ducnnph10350@fpt.edu.vn',
      img: 'https://images.contentstack.io/v3/assets/blt731acb42bb3d1659/bltf945a57aa16cea57/5db05fe7347d1c6baa57be37/RiotX_ChampionList_nautilus.jpg?quality=90&width=250'
    },
    {
      id: 2,
      name: 'ducnnph10350',
      age: 22,
      phone: '0775200414',
      email: 'ducnnph10350@fpt.edu.vn',
      img: 'https://images.contentstack.io/v3/assets/blt731acb42bb3d1659/bltf945a57aa16cea57/5db05fe7347d1c6baa57be37/RiotX_ChampionList_nautilus.jpg?quality=90&width=250'
    },
    {
      id: 3,
      name: 'ducnnph10350',
      age: 22,
      phone: '0775200414',
      email: 'ducnnph10350@fpt.edu.vn',
      img: 'https://images.contentstack.io/v3/assets/blt731acb42bb3d1659/bltf945a57aa16cea57/5db05fe7347d1c6baa57be37/RiotX_ChampionList_nautilus.jpg?quality=90&width=250'
    }
  ];
  remove(id :number){
    this.students = this.students.filter(student => student.id !== id);
  }
  users  = [
    { 
      id: 1,
      ten: 'Nguyen van a',
      nang: 40,
      cao: 170,
      img: 'https://images.contentstack.io/v3/assets/blt731acb42bb3d1659/bltf945a57aa16cea57/5db05fe7347d1c6baa57be37/RiotX_ChampionList_nautilus.jpg?quality=90&width=250',


    },
    { 
      id: 2,
      ten: 'Nguyen van a',
      nang: 29,
      cao: 170,
      img: 'https://images.contentstack.io/v3/assets/blt731acb42bb3d1659/bltf945a57aa16cea57/5db05fe7347d1c6baa57be37/RiotX_ChampionList_nautilus.jpg?quality=90&width=250',


    },
    { 
      id: 3,
      ten: 'Nguyen van a',
      nang: 10,
      cao: 170,
      img: 'https://images.contentstack.io/v3/assets/blt731acb42bb3d1659/bltf945a57aa16cea57/5db05fe7347d1c6baa57be37/RiotX_ChampionList_nautilus.jpg?quality=90&width=250',


    }
  ];
  removes(nang :number){
    if(nang>30){
      this.users = this.users.filter(user => user.nang < 30);
    }
  }
}
